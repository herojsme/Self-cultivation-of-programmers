// pages/index/index.js
Page({
  data: {
  },
  fnScan(){
    console.log(this)
    /*wx.scanCode({
      success(res){
        console.log(res.result);
      },
      fail(err){
        console.log('扫码失败', err);
      }
    });*/
  },
  onLoad: function (options) {
  
  },
  onReady: function () {
  
  },
  onShow: function () {
  
  },
  onHide: function () {
  
  },
  onUnload: function () {
  
  },
  onPullDownRefresh: function () {
  
  },
  onReachBottom: function () {
  
  },
  onShareAppMessage: function () {
  
  }
})