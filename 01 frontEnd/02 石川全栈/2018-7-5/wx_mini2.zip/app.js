//app.js
App({
  onLaunch: function () {
  },
  globalData: {
    appName: 'testttt'
  }
})