//app.js
App({
  onLaunch: function () {
  },
  globalData: {
    a: 1
  }
})