// pages/index/index.js
Page({
  data: {
    now: 0,
    arr: ['关注', '科技', '媒体', '体育', '美食', '母婴', '电商', '其他']
  },
  setNow(ev){
    console.log(ev);

    this.setData({
      now: ev.target.dataset.index
    });
  },
  fnLoad(){
    wx.request({
      url: 'http://localhost:8080/',
      dataType: 'json',
      success(res){
        console.log(res.data);
      },
      fail(e){
        console.log('错误', e);
      }
    });
  },
  onLoad: function (options) {
  
  },
  onReady: function () {
  
  },
  onShow: function () {
  
  },
  onHide: function () {
  
  },
  onUnload: function () {
  
  },
  onPullDownRefresh: function () {
  
  },
  onReachBottom: function () {
  
  },
  onShareAppMessage: function () {
  
  }
})