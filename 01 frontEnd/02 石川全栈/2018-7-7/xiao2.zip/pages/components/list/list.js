// pages/components/list/list.js
Component({
  data: {
    arr: [12,5,8,47,36]
  }
})

module.exports={
  sum(a, b) {
    return a + b;
  }
}