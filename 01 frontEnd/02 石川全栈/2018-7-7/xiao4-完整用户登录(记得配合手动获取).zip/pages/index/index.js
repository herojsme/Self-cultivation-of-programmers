Page({
  data: {
    userinfo: null
  },
  getUserInfo(){
    wx.login({
      success(res){
        console.log('成功', res);
      },
      fail(err){
        console.log('失败', err);
      }
    })
  }
});