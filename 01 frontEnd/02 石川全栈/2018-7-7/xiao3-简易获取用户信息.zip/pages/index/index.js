Page({
  data: {
    userinfo: null
  },
  getUserInfo(){
    wx.getUserInfo({
      success: res=>{
        console.log('成功', res.userInfo);

        this.setData({
          userinfo: res.userInfo
        });
      },
      fail(err){
        console.log('错误', err);
      }
    })
  }
});