<template>
  <div>
    <h1>About page</h1>
    <nuxt-link to="/">Home</nuxt-link>
  </div>
</template>

<script>
export default {
  name: 'AboutPage'
}
</script>

<style>

</style>
