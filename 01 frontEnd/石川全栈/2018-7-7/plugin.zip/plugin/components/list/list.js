let common=require('/libs/common');

Component({
  data: {
    name: '张三',
    age: common.sum(18,7)
  },
  attached: function(){
  },
})