const common=require('/libs/common');

module.exports={
  common: common
};