var plugin = requirePlugin("myPlugin")

Page({
  onLoad: function() {
    console.log(plugin.common.mul(99, 87659));
  }
})